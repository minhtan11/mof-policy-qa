import { Injectable, signal } from '@angular/core';

export interface ToastMessage {
  id: string;
  severity: 'success' | 'info' | 'warn' | 'error';
  summary: string;
  detail?: string;
  life?: number;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly messages = signal<ToastMessage[]>([]);

  show(input: Omit<ToastMessage, 'id'>): void {
    const message: ToastMessage = { id: crypto.randomUUID(), life: 4000, ...input };
    this.messages.update((items) => [...items, message]);
    window.setTimeout(() => this.dismiss(message.id), message.life ?? 4000);
  }

  dismiss(id: string): void {
    this.messages.update((items) => items.filter((item) => item.id !== id));
  }
}
