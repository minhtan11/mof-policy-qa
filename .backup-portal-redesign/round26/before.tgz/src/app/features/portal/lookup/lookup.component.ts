import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PortalHeaderComponent } from '../../../shared/ui/portal-header/portal-header.component';
import { MockDbService } from '../../../core/mock-api/mock-db.service';
import { StatusBadgeComponent } from '../../../shared/ui/status-badge/status-badge.component';
import { TranslatePipe } from '../../../core/i18n/translate.pipe';
import { MofButtonComponent } from '../../../shared/ui/mof-button/mof-button.component';
import { MofIconComponent } from '../../../shared/ui/mof-icon/mof-icon.component';

/** Screen PUB-lookup | Citizen/business | Search public answers and track submitted dossiers. | UC-162..UC-165 */
@Component({
  imports: [
    PortalHeaderComponent,
    FormsModule,
    DatePipe,
    RouterLink,
    StatusBadgeComponent,
    TranslatePipe,
    MofButtonComponent,
    MofIconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './lookup.component.html',
  styleUrl: './lookup.component.scss',
})
export class LookupComponent {
  readonly db = inject(MockDbService);
  private readonly route = inject(ActivatedRoute);

  readonly query = signal(this.route.snapshot.queryParamMap.get('q') ?? '');
  readonly results = computed(() => {
    const q = this.query().trim().toLocaleLowerCase();
    return this.db
      .dossiers()
      .filter((d) => !q || [d.code, d.question, d.answer, d.sender].join(' ').toLocaleLowerCase().includes(q));
  });

  topicName(id: string): string {
    return this.db.topics.find((t) => t.id === id)?.name ?? 'Policy';
  }
}
