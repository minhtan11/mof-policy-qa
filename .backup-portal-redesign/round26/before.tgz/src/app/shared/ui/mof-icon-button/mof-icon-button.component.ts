import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { MofIconComponent, MofIconName } from '../mof-icon/mof-icon.component';

/**
 * Nút chỉ-icon dùng chung: ô vuông kích thước token (`--mof-icon-btn-sm|md`), icon SVG căn giữa bằng grid
 * (line-height 0) → vòng hover luôn đồng tâm với icon. Bắt buộc `label` cho aria-label.
 */
@Component({
  selector: 'app-mof-icon-button',
  imports: [MofIconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button
      type="button"
      class="mof-icon-btn"
      [class]="'mof-icon-btn is-' + size() + ' is-' + variant()"
      [attr.aria-label]="label()"
      [attr.title]="label()"
      [disabled]="disabled()"
    >
      <app-mof-icon class="ico" [name]="icon()" [size]="size() === 'sm' ? 14 : 16" />
    </button>
  `,
  styleUrl: './mof-icon-button.component.scss',
})
export class MofIconButtonComponent {
  readonly icon = input.required<MofIconName>();
  readonly label = input.required<string>();
  readonly size = input<'sm' | 'md'>('md');
  readonly variant = input<'ghost' | 'danger'>('ghost');
  readonly disabled = input(false);
}
